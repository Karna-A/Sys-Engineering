#include "Arduino.h"

extern uint32_t ulp_entry;
extern uint32_t ulp_toggle_clear;
extern uint32_t ulp_toggle_complete;
extern uint32_t ulp_wake_up;
extern uint32_t ulp_toggle_counter;
