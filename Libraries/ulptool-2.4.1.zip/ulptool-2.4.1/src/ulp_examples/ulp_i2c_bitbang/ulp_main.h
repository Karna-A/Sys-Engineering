#include "Arduino.h"

extern uint32_t ulp_entry;
extern uint32_t ulp_result;
