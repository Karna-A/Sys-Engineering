#include "Arduino.h"

extern uint32_t ulp_entry;
extern uint32_t ulp_sample_counter;
extern uint32_t ulp_low_thr;
extern uint32_t ulp_error_thr;
extern uint32_t ulp_last_result;
