#include "Arduino.h"

extern uint32_t ulp_entry;
extern uint32_t ulp_Sens_Vp0;
extern uint32_t ulp_Sens_Vn0;
extern uint32_t ulp_Sens_Vp1;
extern uint32_t ulp_Sens_Vn1;
