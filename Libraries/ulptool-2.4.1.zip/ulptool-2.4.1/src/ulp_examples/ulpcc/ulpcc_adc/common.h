// Number of ADC samples to average on each measurement.
#define adc_oversampling_factor 128
